// S01 — Cover (V2). THE WEB'S BIGGEST BLIND SPOT. Left: title + JP's copy + source. Right: a floating 3D mockup of an
// ecommerce home page (Magnific, transparent) with parallax and a faint scanner beam crossing it in a loop.
import { gsap, T, sec } from '@lib/motion/ease.js'
import { Stagger } from '@lib/motion/stagger.js'
import { Parallax } from '@lib/motion/parallax.js'
import { el, prefersReduced } from '@lib/util/dom.js'
import { heading, tile } from '../components/ui.js'

const MOCK = 'dR-s01-mockup-single'
export default {
  id: 's01', title: 'Blind spot', transition: 'fade',
  get notes() { return this._notes },
  build(root, ctx) {
    const { copy, assets } = ctx
    this._notes = copy.s01.notes
    // first line white, every later line in the accent colour; one array entry per rendered line so the h1 box shrink-wraps the text
    const title = heading(copy.s01.title, { tag: 'h1', cls: 'h-display s01-title', accent: copy.s01.title.map((_, i) => i).slice(1), accentClass: 'is-accent' })
    const sub = el('p', { class: 's01-sub', text: copy.s01.sub })
    const stats = copy.s01.stats.map((s) => tile(s, { cls: 's01-stat tile--bare', size: 'm' }))
    const statsRow = el('div', { class: 's01-stats' }, ...stats.map((s) => s.el))
    const beam = el('div', { class: 'beam beam--bg', 'aria-hidden': 'true' })
    const anim = el('div', { class: 's01-mock-anim' }, assets.img(MOCK, { w: 1600, sizes: '58vw', alt: 'A floating ecommerce home page' }), beam)
    const inner = el('div', { class: 's01-mock-inner' }, anim)
    const mock = el('figure', { class: 's01-mock' }, inner)
    // .s01-head shrink-wraps the headline so the paragraph under it spans exactly the headline's width on desktop (see style.css)
    root.append(el('div', { class: 's01-copy' }, el('div', { class: 's01-head' }, title.el, sub), statsRow), mock)
    this.els = { title, sub, stats, statsRow, mock, inner, anim, beam }
    this.parallax = Parallax([{ el: inner, depth: .35 }], { pointer: 18, scroll: 0 })
    gsap.set([sub, statsRow], { opacity: 0 })
    gsap.set(anim, { opacity: 0 })
  },
  preload(ctx) { return ctx.assets.preload([MOCK], 1600) },
  enter(ctx) {
    const { title, sub, stats, statsRow, anim, inner, beam } = this.els
    this.tl?.kill(); this.loop?.kill(); this.drift?.kill()
    const tl = gsap.timeline()
    tl.fromTo(anim, { opacity: 0, y: 40, scale: .96 }, { opacity: 1, y: 0, scale: 1, duration: sec(T[6]), ease: 'out-expo' }, .3)
    tl.add(() => title.restart(), .5)
    tl.add(Stagger([sub, statsRow], { dur: T[4], y: 10, delay: 140 }), 1.5)
    stats.forEach((s, i) => tl.call(() => s.play(), [], 1.9 + i * .12))
    this.tl = tl
    if (!prefersReduced()) {
      this.drift = gsap.to(inner.querySelector('img'), { y: -8, duration: 5, ease: 'sine.inOut', yoyo: true, repeat: -1 })
      this.loop = gsap.fromTo(beam, { top: '-4%', opacity: .35 }, { top: '104%', duration: 7, ease: 'none', repeat: -1, repeatDelay: 2, delay: 1.5 })
    }
    this.parallax.start()
  },
  leave() { this.tl?.kill(); this.loop?.kill(); this.drift?.kill(); this.parallax.stop() },
}
